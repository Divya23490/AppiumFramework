using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework;
using NUnit.Framework.Interfaces;

namespace AppiumFramework.Reports
{
    public class ReportManager
    {
        private static AventStack.ExtentReports.ExtentReports extent;
        private static ExtentHtmlReporter htmlReporter;
        private static string reportPath;

        [ThreadStatic]
        public static ExtentTest test;

        public static void StartReport()
        {
            string reportsDirectory = Path.Combine(TestContext.CurrentContext.WorkDirectory, "TestReports");
            Directory.CreateDirectory(reportsDirectory);

            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            reportPath = Path.Combine(reportsDirectory, $"ExtentReport_{timestamp}.html");

            htmlReporter = new ExtentHtmlReporter(reportPath);
            htmlReporter.Config.DocumentTitle = "Appium Test Execution Report";
            htmlReporter.Config.ReportName = "Test Summary";
            htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Standard;

            extent = new AventStack.ExtentReports.ExtentReports();
            extent.AttachReporter(htmlReporter);
        }

        public void CreateTest()
        {
            test = extent.CreateTest(TestContext.CurrentContext.Test.Name);
        }

        public void LogTestStatus()
        {
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            var message = TestContext.CurrentContext.Result.Message;
            string stacktrace = string.IsNullOrEmpty(TestContext.CurrentContext.Result.StackTrace) ? string.Empty : TestContext.CurrentContext.Result.StackTrace;

            Status logStatus = status switch
            {
                TestStatus.Failed => Status.Fail,
                TestStatus.Inconclusive => Status.Warning,
                TestStatus.Skipped => Status.Skip,
                _ => Status.Pass,
            };

            test.Log(logStatus, $"<b>Status:</b> {logStatus}<br><b>Message:</b> {message}<br><pre>{stacktrace}</pre>");
            extent.Flush();
        }

        public void AddScreenshot(string snapshotPath)
        {
            if (File.Exists(snapshotPath))
            {
                test.AddScreenCaptureFromPath(snapshotPath);
            }
        }
    }
}

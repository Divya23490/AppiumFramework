using AppiumFramework.Reports;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace AppiumFramework.Utils;

public class CommonUtils
{
        public static ThreadLocal<AppiumDriver<IWebElement>> driver = new();
        public static AppiumDriver<IWebElement> GetDriver() => driver.Value;

        public enum SwipeDirection
        {
            Up,
            Down,
            Left,
            Right
        }

        public void ClickOnElement(By element)
        {
            try
            {
                WaitForElement(element);
                GetDriver().FindElement(element).Click();
                ReportManager.test.Info($"Clicked on element {element}");
            }
            catch (Exception e)
            {
                throw new Exception($"Click failed for element {element}: {e.Message}");
            }
        }

        public void SendKeysToElement(By element, string text)
        {
            try
            {
                WaitForElement(element);
                GetDriver().FindElement(element).SendKeys(text);
                ReportManager.test.Info($"Sent keys to {element}");
            }
            catch (Exception e)
            {
                throw new Exception($"SendKeys failed for element {element}: {e.Message}");
            }
        }

        public bool IsElementAppears(By element)
        {
            try
            {
                return GetDriver().FindElement(element).Displayed;
            }
            catch
            {
                return false;
            }
        }
        public void WaitForElement(By element, int timeout = 30)
        {
            try
            {
                new WebDriverWait(GetDriver(), TimeSpan.FromSeconds(timeout))
                    .Until(driver =>
                    {
                        try
                        {
                            var el = driver.FindElement(element);
                            return el.Displayed;
                        }
                        catch
                        {
                            return false;
                        }
                    });
            }
            catch (Exception e)
            {
                throw new Exception($"Timeout waiting for element {element}: {e.Message}");
            }
        }


        public void ScrollIOS(SwipeDirection direction, By targetElement)
        {
            int attempts = 3;
            var args = new Dictionary<string, object>
            {
                ["direction"] = direction.ToString().ToLower()
            };

            try
            {
                for (int i = 0; i < attempts && !IsElementAppears(targetElement); i++)
                {
                    GetDriver().ExecuteScript("mobile: scroll", args);
                    Thread.Sleep(500);
                }
                ReportManager.test.Info($"iOS scroll {direction} to {targetElement}");
            }
            catch (Exception e)
            {
                throw new Exception($"iOS scroll failed: {e.Message}");
            }
        }

        public void SwipeByCoordinates(SwipeDirection direction, By targetElement)
        {
            int width = GetDriver().Manage().Window.Size.Width;
            int height = GetDriver().Manage().Window.Size.Height;

            int startX = 0, startY = 0, endX = 0, endY = 0;

            switch (direction)
            {
                case SwipeDirection.Up:
                    startX = endX = width / 2;
                    startY = (int)(height * 0.8);
                    endY = (int)(height * 0.2);
                    break;
                case SwipeDirection.Down:
                    startX = endX = width / 2;
                    startY = (int)(height * 0.2);
                    endY = (int)(height * 0.8);
                    break;
                case SwipeDirection.Left:
                    startY = endY = height / 2;
                    startX = (int)(width * 0.8);
                    endX = (int)(width * 0.2);
                    break;
                case SwipeDirection.Right:
                    startY = endY = height / 2;
                    startX = (int)(width * 0.2);
                    endX = (int)(width * 0.8);
                    break;
            }

            try
            {
                var touch = new PointerInputDevice(PointerKind.Touch);
                var swipe = new ActionSequence(touch, 0);

                swipe.AddAction(touch.CreatePointerMove(CoordinateOrigin.Viewport, startX, startY, TimeSpan.Zero));
                swipe.AddAction(touch.CreatePointerDown(0));
                swipe.AddAction(touch.CreatePointerMove(CoordinateOrigin.Viewport, endX, endY, TimeSpan.FromMilliseconds(500)));
                swipe.AddAction(touch.CreatePointerUp(0));

                GetDriver().PerformActions(new List<ActionSequence> { swipe });

                ReportManager.test.Info($"Swiped {direction} to {targetElement}");
            }
            catch (Exception e)
            {
                throw new Exception($"Swipe failed: {e.Message}");
            }
        }


        public void SwitchToNativeContext()
        {
            try
            {
                GetDriver().Context = "NATIVE_APP";
                ReportManager.test.Info("Switched to native context.");
            }
            catch (Exception e)
            {
                throw new Exception($"Failed to switch to native context: {e.Message}");
            }
        }

        public void SwitchToWebViewContext(string contextName)
        {
            try
            {
                foreach (var context in GetDriver().Contexts)
                {
                    if (context.Contains(contextName))
                    {
                        GetDriver().Context = context;
                        ReportManager.test.Info($"Switched to context: {context}");
                        return;
                    }
                }
                throw new Exception("WebView context not found.");
            }
            catch (Exception e)
            {
                throw new Exception($"Switch to WebView failed: {e.Message}");
            }
        }
}

using Microsoft.Extensions.Configuration;

namespace AppiumFramework.Utils
{
    public static class UserCredentials
    {
        private static IConfiguration _config;

        static UserCredentials()
        {
            _config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("ConfigFiles/config.json")
                .Build();
        }

        public static string Username => _config["Username"];
        public static string Password => _config["Password"];
    }
}
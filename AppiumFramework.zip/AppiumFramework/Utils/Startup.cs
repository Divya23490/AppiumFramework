using Microsoft.Extensions.Configuration;

namespace AppiumFramework.Utils
{
    public static class Startup
    {
        private static readonly IConfiguration _config;

        static Startup()
        {
            _config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("ConfigFiles/appsettings.Android.json")
                .Build();
        }

        public static string Read(string key) => _config[key];
    }
}
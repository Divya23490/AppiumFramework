using AppiumFramework.Drivers;
using AppiumFramework.Pages;
using AppiumFramework.Reports;
using AppiumFramework.Utils;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Service;
using OpenQA.Selenium.Appium.Service.Options;


namespace AppiumFramework.Tests
{
    public class TestBase
    {
        private AppiumLocalService appiumLocalService;
        private AppiumServiceBuilder appiumServiceBuilder = new();
        private PlatformCapabilities platformCapabilities = new();
        private ReportManager report = new();

        protected HomePage homePage;

        private enum PlatformType
        {
            Android,
            iOS
        }

        private AppiumDriver<IWebElement> InitializeDriver(PlatformType platformType)
        {
            switch (platformType)
            {
                case PlatformType.Android:
                    string automation = Startup.Read("automationName");
                    if (string.IsNullOrEmpty(automation))
                    {
                        throw new Exception("automationName is missing in appsettings. Please check your ConfigFiles/appsettings.Android.json");
                    }

                    var androidOptions = platformCapabilities.InitAndroidCapabilities();
                    CommonUtils.driver.Value = new AndroidDriver<IWebElement>(appiumLocalService, androidOptions);
                    homePage = new HomePageNative();
                    break;

                default:
                    throw new ArgumentException("No platform selected!");
            }

            return CommonUtils.GetDriver();
        }

        private void StartAppiumServer()
        {
            var relaxedSecurity = new KeyValuePair<string, string>("--base-path", "/wd/hub");

            var appiumJsPath = "/opt/homebrew/lib/node_modules/appium/build/lib/main.js";
            var nodePath = "/opt/homebrew/bin/node";

            var args = new OptionCollector();
            args.AddArguments(relaxedSecurity);

            appiumServiceBuilder = appiumServiceBuilder
                .WithAppiumJS(new FileInfo(appiumJsPath))
                .UsingDriverExecutable(new FileInfo(nodePath))
                .WithIPAddress("127.0.0.1")
                .UsingPort(4723)
                .WithLogFile(new FileInfo("appium_log.txt"))
                .WithArguments(args);

            appiumLocalService = appiumServiceBuilder.Build();

            Console.WriteLine("Starting Appium Server...");

            if (!appiumLocalService.IsRunning)
            {
                appiumLocalService.Start();
                Thread.Sleep(5000);
            }

            if (!appiumLocalService.IsRunning)
                throw new Exception("Appium server failed to start!");
        }

        private void CloseAppiumServer()
        {
            if (appiumLocalService != null && appiumLocalService.IsRunning)
            {
                appiumLocalService.Dispose();
            }
        }

        private void SetUpDriver()
        {
            var platformConfig = Startup.Read("PlatformType");

            if (!Enum.TryParse(platformConfig, ignoreCase: true, out PlatformType platformType))
            {
                throw new Exception($"Invalid or missing PlatformType in config: {platformConfig}");
            }

            InitializeDriver(platformType);
        }

        private void CloseDriver()
        {
            CommonUtils.GetDriver()?.Quit();
        }

        private void AttachScreenshotToTheReport()
        {
            try
            {
                if (CommonUtils.GetDriver() != null && TestContext.CurrentContext.Result.Outcome != ResultState.Success)
                {
                    var screenshot = CommonUtils.GetDriver().GetScreenshot();
                    string screenshotPath = $"{TestContext.CurrentContext.Test.MethodName}.png";
                    screenshot.SaveAsFile(screenshotPath);
                    report.AddScreenshot(screenshotPath);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Failed to capture screenshot: " + e.Message);
            }
        }

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            StartAppiumServer();
            ReportManager.StartReport();
        }

        [OneTimeTearDown]
        public void OneTimeTearDown()
        {
            CloseAppiumServer();
        }

        [SetUp]
        public void SetUp()
        {
            report.CreateTest();
            SetUpDriver();
        }

        [TearDown]
        public void TearDown()
        {
            AttachScreenshotToTheReport();
            report.LogTestStatus();
            CloseDriver();
        }
    }
}

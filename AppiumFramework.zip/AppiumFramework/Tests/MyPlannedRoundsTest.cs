using AppiumFramework.Utils;
using NUnit.Framework;

namespace AppiumFramework.Tests;

public class MyPlannedRoundsTest:TestBase
{
    [Author("Divya Khurana")]
    [Description("Creating My Planned Rounds")]
    [Test]
    public void CreateMyPlannedRounds()
    {
        homePage.ClickNotificationAllow();
        homePage.ClickMyPlannedRounds();
        homePage.ClickSignIn();
        // Send username and password from JSON
        homePage.SignInWithCredentials(UserCredentials.Username, UserCredentials.Password);
        homePage.ClickMySignInButton();
        homePage.ClickAddRoundButton();
        homePage.ClickCourse();
        homePage.ClickPlanAVirtualGoalRound();
        homePage.ClickGreenMaleTeam();
        homePage.ClickSaveButton();
    }
        

       
        
}
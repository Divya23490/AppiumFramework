using AppiumFramework.Utils;
using OpenQA.Selenium;

namespace AppiumFramework.Pages
{
    public abstract class HomePage : CommonUtils
    {
        protected abstract By MyPlannedRounds { get; }
        protected abstract By AddPlannedRounds { get; }
        protected abstract By Course { get; } 
        
        protected abstract By PlanAVirtualGoalRound  { get; }
        
        protected abstract By GreenMaleTeam { get; }
        
        protected abstract By SaveButton { get; }
        
        protected abstract By NotificationAllow { get; }
        
        protected abstract By SignIn { get; }
        
        protected abstract By Username { get; }
        
        protected abstract By Password { get; }
        
        protected abstract By SignInBtn { get; }
        
        
        protected abstract By PlanAVirtualGoal { get; }
        
        protected abstract By GolfIcon { get; }

        public void ClickMyPlannedRounds() => ClickOnElement(MyPlannedRounds);  
        public void ClickAddRoundButton() => ClickOnElement(AddPlannedRounds);
        public void ClickCourse() => ClickOnElement(Course);
        public void ClickPlanAVirtualGoalRound() => ClickOnElement(PlanAVirtualGoalRound);
        public void ClickGreenMaleTeam() => ClickOnElement(GreenMaleTeam);
        public void ClickSaveButton() => ClickOnElement(SaveButton);
        
        public void ClickNotificationAllow() => ClickOnElement(NotificationAllow);
        
        public void ClickSignIn() => ClickOnElement(SignIn);
        
        public void ClickMyUseragent() => ClickOnElement(Username);
        
        public void ClickMyPassword() => ClickOnElement(Password);
        
        public void ClickMySignInButton() => ClickOnElement(SignInBtn);
        
        public void ClickPlanAVirtalGoal()=> ClickOnElement(PlanAVirtualGoal);
        
        public void ClickGolfIcon() => ClickOnElement(GolfIcon);
        
        public void SignInWithCredentials(string username, string password)
        {
           
            SendKeysToElement(Username, username);
            SendKeysToElement(Password, password);
            ClickOnElement(SignInBtn);
        }

        
    }
}
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;

namespace AppiumFramework.Pages;

public class HomePageNative : HomePage
{
    protected override By MyPlannedRounds => MobileBy.AndroidUIAutomator("new UiSelector().text(\"MY PLANNED ROUNDS\")");
    protected override By AddPlannedRounds => By.Id("dk.TrackMan.Range:id/addRoundButton");
    protected override By Course => MobileBy.AndroidUIAutomator("new UiSelector().text(\'Cabot Citrus Farms Karoo\')");
    protected override By PlanAVirtualGoalRound => By.Id("dk.TrackMan.Range:id/actionButton");
    
    protected override By PlanAVirtualGoal => By.Id("dk.TrackMan.Range:id/selectButton"); 
    protected override By GreenMaleTeam => MobileBy.AndroidUIAutomator("new UiSelector().resourceId(\'dk.TrackMan.Range:id/backgroundView\').instance(3)");
    protected override By SaveButton  => By.Id("dk.TrackMan.Range:id/saveButton"); 
    
    protected override By SignIn => By.Id("dk.TrackMan.Range:id/signInButton");
    
    protected override By Username => By.XPath("//android.view.View[@resource-id='Email']");
    
    protected override By Password => By.XPath("//android.view.View[@resource-id='Password']");
    
    protected override By SignInBtn => By.XPath("//android.view.View[@text='SIGN IN']");
    
    protected override By NotificationAllow => By.Id("com.android.permissioncontroller:id/permission_allow_button");

    protected override By GolfIcon => MobileBy.AndroidUIAutomator("new UiSelector().className(\"android.widget.ImageView\").instance(8)");
}
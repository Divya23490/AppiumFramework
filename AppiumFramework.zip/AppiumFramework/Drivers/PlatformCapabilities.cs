using AppiumFramework.Utils;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Enums;

namespace AppiumFramework.Drivers
{
    public class PlatformCapabilities
    {
        public AppiumOptions InitAndroidCapabilities()
        {
            var options = new AppiumOptions();
            options.AddAdditionalCapability(MobileCapabilityType.PlatformName, Startup.Read("PlatformName"));
            options.AddAdditionalCapability("appium:automationName", Startup.Read("automationName"));
            options.AddAdditionalCapability("appium:appPackage", Startup.Read("AppPackage"));
            options.AddAdditionalCapability("appium:appActivity", Startup.Read("AppActivity"));
            options.AddAdditionalCapability(MobileCapabilityType.DeviceName, Startup.Read("DeviceName"));
            options.AddAdditionalCapability(MobileCapabilityType.NoReset, true);
            return options;
        }
    }
}